from flask import Flask, jsonify, request
import redis
import pymysql
import json
import time
import os

app = Flask(__name__)

# Redis 연결
redis_client = redis.Redis(
    host=os.getenv('REDIS_HOST', 'localhost'),
    port=int(os.getenv('REDIS_PORT', 6379)),
    decode_responses=True,
    socket_connect_timeout=5
)

# RDS 연결 설정
db_config = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'user': os.getenv('DB_USER', 'admin'),
    'password': os.getenv('DB_PASSWORD', 'password'),
    'database': os.getenv('DB_NAME', 'labdb'),
    'connect_timeout': 5
}

def get_db_connection():
    return pymysql.connect(**db_config)

@app.route('/')
def index():
    return jsonify({
        'message': 'ElastiCache Lab API',
        'endpoints': {
            '/user/<id>': 'Get user by ID (with cache)',
            '/user/<id>/nocache': 'Get user by ID (without cache)',
            '/products': 'Get all products (with cache)',
            '/cache/stats': 'Get cache statistics',
            '/cache/clear': 'Clear all cache'
        }
    })

@app.route('/user/<int:user_id>')
def get_user(user_id):
    """Cache-Aside 패턴으로 사용자 조회"""
    start_time = time.time()
    cache_key = f"user:{user_id}"
    
    # 1. 캐시에서 조회
    cached_data = redis_client.get(cache_key)
    
    if cached_data:
        elapsed = (time.time() - start_time) * 1000
        return jsonify({
            'source': 'cache',
            'data': json.loads(cached_data),
            'response_time_ms': round(elapsed, 2)
        })
    
    # 2. 캐시 미스 - DB에서 조회
    try:
        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user_data = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user_data:
            # 3. 캐시에 저장 (TTL 1시간)
            redis_client.setex(
                cache_key,
                3600,
                json.dumps(user_data, default=str)
            )
            
            elapsed = (time.time() - start_time) * 1000
            return jsonify({
                'source': 'database',
                'data': user_data,
                'response_time_ms': round(elapsed, 2)
            })
        else:
            return jsonify({'error': 'User not found'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/user/<int:user_id>/nocache')
def get_user_nocache(user_id):
    """캐시 없이 DB에서 직접 조회"""
    start_time = time.time()
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user_data = cursor.fetchone()
        cursor.close()
        conn.close()
        
        elapsed = (time.time() - start_time) * 1000
        
        if user_data:
            return jsonify({
                'source': 'database',
                'data': user_data,
                'response_time_ms': round(elapsed, 2)
            })
        else:
            return jsonify({'error': 'User not found'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/products')
def get_products():
    """상품 목록 조회 (캐시 적용)"""
    start_time = time.time()
    cache_key = "products:all"
    
    # 캐시 확인
    cached_data = redis_client.get(cache_key)
    
    if cached_data:
        elapsed = (time.time() - start_time) * 1000
        return jsonify({
            'source': 'cache',
            'count': len(json.loads(cached_data)),
            'data': json.loads(cached_data),
            'response_time_ms': round(elapsed, 2)
        })
    
    # DB 조회
    try:
        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT * FROM products LIMIT 100")
        products = cursor.fetchall()
        cursor.close()
        conn.close()
        
        # 캐시 저장 (TTL 5분)
        redis_client.setex(
            cache_key,
            300,
            json.dumps(products, default=str)
        )
        
        elapsed = (time.time() - start_time) * 1000
        return jsonify({
            'source': 'database',
            'count': len(products),
            'data': products,
            'response_time_ms': round(elapsed, 2)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/cache/stats')
def cache_stats():
    """캐시 통계 조회"""
    try:
        info = redis_client.info('stats')
        return jsonify({
            'total_connections': info.get('total_connections_received', 0),
            'total_commands': info.get('total_commands_processed', 0),
            'keyspace_hits': info.get('keyspace_hits', 0),
            'keyspace_misses': info.get('keyspace_misses', 0),
            'hit_rate': round(
                info.get('keyspace_hits', 0) / 
                max(info.get('keyspace_hits', 0) + info.get('keyspace_misses', 0), 1) * 100, 
                2
            )
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/cache/clear', methods=['POST'])
def clear_cache():
    """모든 캐시 삭제"""
    try:
        redis_client.flushdb()
        return jsonify({'message': 'Cache cleared successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    """헬스 체크"""
    redis_status = 'connected'
    db_status = 'connected'
    
    try:
        redis_client.ping()
    except:
        redis_status = 'disconnected'
    
    try:
        conn = get_db_connection()
        conn.close()
    except:
        db_status = 'disconnected'
    
    return jsonify({
        'redis': redis_status,
        'database': db_status
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
