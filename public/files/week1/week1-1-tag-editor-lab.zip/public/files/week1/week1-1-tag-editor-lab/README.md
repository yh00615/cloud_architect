# Week 1-1 Tag Editor Lab - CloudFormation 스택 배포 가이드

## 개요

이 CloudFormation 템플릿은 Week 1-1 Tag Editor 실습을 위한 기본 AWS 리소스를 자동으로 생성합니다.

## 생성되는 리소스

### 1. Amazon S3 버킷 (2개)

- **week1-lab-data-bucket-{계정ID}**: 데이터 저장용 버킷
- **week1-lab-logs-bucket-{계정ID}**: 로그 저장용 버킷

**설정**:
- 퍼블릭 액세스 차단 활성화
- 버전 관리 비활성화 (기본값)
- 암호화 비활성화 (기본값)

### 2. AWS Lambda 함수 (1개)

- **Week1TagEditorLabFunction**: Hello World 샘플 함수

**설정**:
- Runtime: Python 3.12
- Handler: index.lambda_handler
- 메모리: 128MB (기본값)
- 타임아웃: 3초 (기본값)

**코드**:
```python
import json

def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Week 1-1 Tag Editor Lab!')
    }
```

### 3. Amazon DynamoDB 테이블 (1개)

- **Week1TagEditorLabTable**: 샘플 데이터 테이블

**설정**:
- Billing Mode: PAY_PER_REQUEST (온디맨드)
- Partition Key: id (String)
- Sort Key: 없음

### 4. IAM 역할 (1개)

- **Week1TagEditorLabLambdaRole**: Lambda 함수 실행 역할

**권한**:
- AWSLambdaBasicExecutionRole (CloudWatch Logs 쓰기 권한)

## 태그 전략

모든 리소스에 다음 태그가 자동으로 추가됩니다:

| Tag Key | Tag Value | 설명 |
|---------|-----------|------|
| `Project` | `AWS-Lab` | 프로젝트 식별자 |
| `Week` | `1-1` | 주차 및 세션 번호 |
| `CreatedBy` | `CloudFormation` | 생성 방법 |

> [!NOTE]
> 실습 중에 S3 버킷에 수동으로 태그를 추가하여 `CreatedBy` 값을 `Student`로 변경합니다.

## 배포 방법

### 1. AWS Management Console 사용

1. AWS Management Console에 로그인합니다.
2. CloudFormation 서비스로 이동합니다.
3. [[Create stack]] 버튼을 클릭합니다.
4. **Upload a template file**을 선택하고 `tag-editor-lab-stack.yaml` 파일을 업로드합니다.
5. 스택 이름: `week1-1-tag-editor-lab-stack`
6. 파라미터는 기본값을 사용합니다.
7. [[Next]] → [[Next]] → [[Submit]] 버튼을 클릭합니다.
8. 스택 생성이 완료될 때까지 기다립니다 (2-3분 소요).

### 2. AWS CLI 사용

```bash
aws cloudformation create-stack \
  --stack-name week1-1-tag-editor-lab-stack \
  --template-body file://tag-editor-lab-stack.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --region ap-northeast-2
```

## 출력값 (Outputs)

스택 생성 완료 후 다음 출력값을 확인할 수 있습니다:

| Output Key | 설명 | 예시 값 |
|-----------|------|---------|
| `DataBucketName` | 데이터 버킷 이름 | week1-lab-data-bucket-123456789012 |
| `LogsBucketName` | 로그 버킷 이름 | week1-lab-logs-bucket-123456789012 |
| `DynamoDBTableName` | DynamoDB 테이블 이름 | Week1TagEditorLabTable |
| `LambdaFunctionName` | Lambda 함수 이름 | Week1TagEditorLabFunction |
| `LambdaFunctionArn` | Lambda 함수 ARN | arn:aws:lambda:ap-northeast-2:123456789012:function:Week1TagEditorLabFunction |

## 비용 정보

이 스택에서 생성하는 모든 리소스는 AWS 프리티어 범위 내에서 사용 가능합니다:

| 리소스 | 프리티어 | 비용 |
|--------|---------|------|
| S3 버킷 | 5GB 스토리지 | 사용하지 않으면 $0 |
| Lambda 함수 | 100만 요청/월 | 사용하지 않으면 $0 |
| DynamoDB 테이블 | 25GB 스토리지 | 사용하지 않으면 $0 |
| IAM 역할 | 무료 | $0 |

> [!NOTE]
> 실습 종료 후 스택을 삭제하면 모든 리소스가 자동으로 삭제되어 비용이 발생하지 않습니다.

## 스택 삭제

실습 종료 후 다음 방법으로 스택을 삭제합니다:

### 1. AWS Management Console 사용

1. CloudFormation 콘솔로 이동합니다.
2. `week1-1-tag-editor-lab-stack` 스택을 선택합니다.
3. [[Delete]] 버튼을 클릭합니다.
4. 확인 창에서 [[Delete]] 버튼을 클릭합니다.
5. 스택 삭제가 완료될 때까지 기다립니다 (2-3분 소요).

### 2. AWS CLI 사용

```bash
aws cloudformation delete-stack \
  --stack-name week1-1-tag-editor-lab-stack \
  --region ap-northeast-2
```

## 문제 해결

### 문제 1: S3 버킷 이름 충돌

**증상**: "Bucket name already exists" 오류 발생

**원인**: S3 버킷 이름은 전 세계적으로 고유해야 하는데, 이미 사용 중인 이름입니다.

**해결**:
1. CloudFormation 콘솔에서 스택을 삭제합니다.
2. 템플릿의 `BucketSuffix` 파라미터를 수정하여 고유한 값을 사용합니다.
3. 스택을 다시 생성합니다.

### 문제 2: IAM 역할 생성 권한 부족

**증상**: "User is not authorized to perform: iam:CreateRole" 오류 발생

**원인**: IAM 역할을 생성할 권한이 없습니다.

**해결**:
1. AWS 계정 관리자에게 IAM 권한을 요청합니다.
2. 또는 관리자가 스택을 대신 생성합니다.

### 문제 3: 스택 삭제 실패

**증상**: S3 버킷이 비어있지 않아 삭제 실패

**원인**: S3 버킷에 객체가 있으면 CloudFormation이 자동으로 삭제할 수 없습니다.

**해결**:
1. S3 콘솔로 이동합니다.
2. 해당 버킷을 선택하고 모든 객체를 삭제합니다.
3. CloudFormation 스택을 다시 삭제합니다.

## 추가 정보

- [AWS CloudFormation 사용 설명서](https://docs.aws.amazon.com/cloudformation/)
- [AWS 프리티어](https://aws.amazon.com/free/)
- [AWS 리소스 태그 전략](https://docs.aws.amazon.com/general/latest/gr/aws_tagging.html)

---

**마지막 업데이트**: 2025-02-16  
**버전**: 1.0.0
