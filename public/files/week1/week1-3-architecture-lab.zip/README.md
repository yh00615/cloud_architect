# AWS 고가용성 아키텍처 다이어그램 실습 가이드

이 가이드는 Draw.io를 사용하여 AWS 고가용성 아키텍처를 설계하는 실습을 위한 참고 자료입니다.

## 📦 실습 목표

- Draw.io를 사용하여 AWS 아키텍처 다이어그램 작성
- Multi-AZ 고가용성 설계 원칙 적용
- 3-Tier 아키텍처 구성 요소 이해

## 🚀 Draw.io 빠른 시작

### 1. Draw.io 접속

**URL**: https://app.diagrams.net/?splash=0&libs=aws4

**파라미터 설명**:
- `splash=0` - 시작 화면 건너뛰기
- `libs=aws4` - AWS 아이콘 라이브러리 자동 로드

### 2. 언어 설정

**메뉴**: Extras > Language > English

### 3. 새 다이어그램 생성

1. Create New Diagram
2. Blank Diagram 선택
3. 파일명: `aws-ha-architecture`
4. 저장 위치 선택 (Device, Google Drive, OneDrive 등)

## 🏗️ 아키텍처 구성 요소

### VPC 및 네트워크

| 구성 요소 | CIDR | 설명 |
|----------|------|------|
| VPC | 10.0.0.0/16 | 전체 네트워크 범위 |
| Public Subnet A | 10.0.1.0/24 | ap-northeast-2a |
| Public Subnet C | 10.0.2.0/24 | ap-northeast-2c |
| Private App Subnet A | 10.0.11.0/24 | ap-northeast-2a |
| Private App Subnet C | 10.0.12.0/24 | ap-northeast-2c |
| Private DB Subnet A | 10.0.21.0/24 | ap-northeast-2a |
| Private DB Subnet C | 10.0.22.0/24 | ap-northeast-2c |

### 보안 그룹 규칙

#### ALB Security Group
```
Inbound:
- Port 80 (HTTP) from 0.0.0.0/0
- Port 443 (HTTPS) from 0.0.0.0/0

Outbound:
- All traffic to Web Tier SG
```

#### Web Tier Security Group
```
Inbound:
- Port 80 from ALB SG
- Port 443 from ALB SG

Outbound:
- All traffic to App Tier SG
```

#### App Tier Security Group
```
Inbound:
- Port 8080 from Web Tier SG

Outbound:
- All traffic to DB SG
```

#### DB Security Group
```
Inbound:
- Port 3306 (MySQL) from App Tier SG

Outbound:
- None (데이터베이스는 아웃바운드 불필요)
```

## 🎨 다이어그램 작성 팁

### 색상 구분

- **초록색**: Public Subnet (인터넷 접근 가능)
- **파란색**: Private App Subnet (애플리케이션 계층)
- **보라색**: Private DB Subnet (데이터베이스 계층)

### 화살표 사용

- **실선 화살표**: 데이터 흐름
- **점선 화살표**: 관리/모니터링 연결
- **양방향 화살표**: 동기화/복제

### 레이블 작성

- **명확한 이름**: 각 구성 요소의 역할을 명시
- **CIDR 표기**: 서브넷에는 CIDR 블록 포함
- **포트 정보**: 보안 그룹에는 허용 포트 명시

## 📋 체크리스트

### 필수 구성 요소

- [ ] VPC (10.0.0.0/16)
- [ ] 2개의 가용 영역 (ap-northeast-2a, ap-northeast-2c)
- [ ] 6개의 서브넷 (Public x2, Private App x2, Private DB x2)
- [ ] Internet Gateway
- [ ] NAT Gateway x2 (각 AZ에 1개씩)
- [ ] Application Load Balancer
- [ ] Web Tier EC2 x2 + Auto Scaling
- [ ] App Tier EC2 x2 + Auto Scaling
- [ ] RDS Multi-AZ (Primary + Standby)
- [ ] 4개의 Security Group (ALB, Web, App, DB)

### 연결 확인

- [ ] Internet Gateway → Public Subnet
- [ ] NAT Gateway → Private Subnet
- [ ] ALB → Web Tier
- [ ] Web Tier → App Tier
- [ ] App Tier → RDS Primary
- [ ] RDS Primary ↔ RDS Standby (Synchronous Replication)

## 🔍 AWS Well-Architected Framework 원칙

### 1. 안정성 (Reliability)

**Multi-AZ 배포**
- 최소 2개 이상의 가용 영역 사용
- 단일 장애점(SPOF) 제거
- 자동 페일오버 구성

**자동 복구**
- Auto Scaling으로 인스턴스 자동 교체
- RDS Multi-AZ 자동 페일오버
- Health Check 기반 트래픽 라우팅

### 2. 보안 (Security)

**계층화된 보안**
- Public/Private Subnet 분리
- Security Group 최소 권한 원칙
- 각 계층별 접근 제어

**네트워크 격리**
- Private Subnet은 인터넷 직접 접근 불가
- NAT Gateway를 통한 아웃바운드만 허용
- DB는 App Tier에서만 접근 가능

### 3. 성능 효율성 (Performance Efficiency)

**수평 확장**
- Auto Scaling으로 트래픽에 따라 자동 확장
- Load Balancer로 트래픽 분산
- 각 계층 독립적으로 확장 가능

**리소스 최적화**
- 적절한 인스턴스 타입 선택
- 캐싱 전략 적용 (ElastiCache 추가 가능)
- CDN 활용 (CloudFront 추가 가능)

### 4. 비용 최적화 (Cost Optimization)

**탄력적 리소스**
- Auto Scaling으로 필요한 만큼만 사용
- Reserved Instance로 비용 절감
- Spot Instance 활용 (비프로덕션 환경)

**리소스 모니터링**
- CloudWatch로 사용률 모니터링
- 미사용 리소스 정리
- 적절한 인스턴스 크기 조정

## 💡 고급 아키텍처 개선 사항

### 추가 가능한 구성 요소

1. **CloudFront (CDN)**
   - 정적 콘텐츠 캐싱
   - 글로벌 배포
   - DDoS 보호

2. **ElastiCache (Redis/Memcached)**
   - 세션 저장소
   - 데이터베이스 쿼리 캐싱
   - 성능 향상

3. **Route 53 (DNS)**
   - Health Check 기반 라우팅
   - 지리적 라우팅
   - 페일오버 라우팅

4. **WAF (Web Application Firewall)**
   - SQL Injection 방어
   - XSS 공격 방어
   - Rate Limiting

5. **CloudWatch + SNS**
   - 리소스 모니터링
   - 알람 설정
   - 자동 알림

## 📤 다이어그램 내보내기

### PNG 내보내기

1. File > Export as > PNG
2. 해상도: 300% (고해상도)
3. 배경: 투명 또는 흰색
4. 파일명: `aws-ha-architecture.png`

### PDF 내보내기

1. File > Export as > PDF
2. 페이지 크기: A4 또는 Letter
3. 파일명: `aws-ha-architecture.pdf`

### 원본 저장

1. File > Save
2. 형식: .drawio 또는 .xml
3. 저장 위치: Device, Google Drive, OneDrive 등

## 🔗 추가 리소스

### AWS 공식 문서

- [AWS Architecture Center](https://aws.amazon.com/architecture/)
- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)
- [AWS Reference Architectures](https://aws.amazon.com/architecture/reference-architecture-diagrams/)

### Draw.io 리소스

- [Draw.io 공식 사이트](https://www.diagrams.net/)
- [AWS Architecture Icons](https://aws.amazon.com/architecture/icons/)
- [Draw.io AWS 라이브러리](https://github.com/aws/aws-icons-for-plantuml)

### 아키텍처 예시

- [3-Tier Web Application](https://docs.aws.amazon.com/whitepapers/latest/web-application-hosting-best-practices/an-aws-cloud-architecture-for-web-hosting.html)
- [High Availability Architecture](https://docs.aws.amazon.com/whitepapers/latest/real-time-communication-on-aws/high-availability-architecture.html)
- [Multi-Region Architecture](https://docs.aws.amazon.com/whitepapers/latest/building-scalable-secure-multi-vpc-network-infrastructure/multi-region-architecture.html)

## 📝 실습 후 확인 사항

### 아키텍처 검증

- [ ] 모든 구성 요소가 올바르게 배치되었는가?
- [ ] Multi-AZ 구성이 적용되었는가?
- [ ] 보안 그룹 규칙이 최소 권한 원칙을 따르는가?
- [ ] 단일 장애점(SPOF)이 없는가?
- [ ] 각 계층이 명확히 분리되었는가?

### 다이어그램 품질

- [ ] 레이블이 명확하고 읽기 쉬운가?
- [ ] 화살표가 데이터 흐름을 정확히 표현하는가?
- [ ] 색상 구분이 일관성 있게 적용되었는가?
- [ ] 다이어그램이 깔끔하고 정돈되어 있는가?
- [ ] 고해상도로 내보내기가 완료되었는가?

## 🎓 학습 목표 달성 확인

- [ ] Draw.io를 사용하여 AWS 아키텍처 다이어그램을 작성할 수 있다
- [ ] Multi-AZ 고가용성 설계 원칙을 적용할 수 있다
- [ ] 3-Tier 아키텍처의 구성 요소를 이해한다
- [ ] AWS Well-Architected Framework의 안정성 원칙을 이해한다
- [ ] 보안 그룹을 사용한 계층화된 보안을 구현할 수 있다
