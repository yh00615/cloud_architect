"""
AWS Lambda 함수: Secrets Manager 및 Parameter Store 통합 데모

이 Lambda 함수는 AWS Secrets Manager와 Systems Manager Parameter Store를
사용하여 민감한 정보와 애플리케이션 설정을 안전하게 조회하는 방법을 보여줍니다.

주요 기능:
    1. Secrets Manager에서 데이터베이스 자격증명 조회
    2. Secrets Manager에서 API 키 조회
    3. Parameter Store에서 일반 파라미터 조회
    4. Parameter Store에서 암호화된 파라미터 조회
    5. 경로 기반으로 여러 파라미터 일괄 조회

환경 변수:
    없음

트리거:
    수동 실행 또는 EventBridge 스케줄

작성자: AWS 실습 가이드
버전: 1.0.0
"""

import json
import boto3
from botocore.exceptions import ClientError

# AWS 클라이언트 초기화
secrets_client = boto3.client('secretsmanager')  # Secrets Manager 클라이언트
ssm_client = boto3.client('ssm')  # Systems Manager 클라이언트

def get_secret(secret_name):
    """
    Secrets Manager에서 시크릿 조회
    
    지정된 이름의 시크릿을 Secrets Manager에서 조회하고
    JSON 형식으로 파싱하여 반환합니다.
    
    Args:
        secret_name (str): 조회할 시크릿 이름
    
    Returns:
        dict: 시크릿 값 (JSON 파싱 결과)
    
    Raises:
        ClientError: 시크릿 조회 실패 시
    
    Example:
        >>> credentials = get_secret('prod/db/mysql/credentials')
        >>> print(credentials['username'])
        admin
    """
    try:
        # Secrets Manager에서 시크릿 값 조회
        response = secrets_client.get_secret_value(SecretId=secret_name)
        # JSON 문자열을 딕셔너리로 변환하여 반환
        return json.loads(response['SecretString'])
    except ClientError as e:
        # 오류 발생 시 로그 출력 및 예외 재발생
        print(f"Error retrieving secret: {e}")
        raise e

def get_parameter(parameter_name, with_decryption=True):
    """
    Parameter Store에서 파라미터 조회
    
    지정된 이름의 파라미터를 Parameter Store에서 조회합니다.
    암호화된 파라미터(SecureString)는 자동으로 복호화됩니다.
    
    Args:
        parameter_name (str): 조회할 파라미터 이름
        with_decryption (bool): 암호화된 파라미터 복호화 여부 (기본값: True)
    
    Returns:
        str: 파라미터 값
    
    Raises:
        ClientError: 파라미터 조회 실패 시
    
    Example:
        >>> region = get_parameter('/prod/app/config/region', with_decryption=False)
        >>> print(region)
        ap-northeast-2
    """
    try:
        # Parameter Store에서 파라미터 조회
        response = ssm_client.get_parameter(
            Name=parameter_name,
            WithDecryption=with_decryption  # SecureString 복호화 여부
        )
        # 파라미터 값 반환
        return response['Parameter']['Value']
    except ClientError as e:
        # 오류 발생 시 로그 출력 및 예외 재발생
        print(f"Error retrieving parameter: {e}")
        raise e

def get_parameters_by_path(path, with_decryption=True):
    """
    경로로 여러 파라미터 일괄 조회
    
    지정된 경로 아래의 모든 파라미터를 재귀적으로 조회합니다.
    계층 구조로 구성된 설정을 한 번에 가져올 때 유용합니다.
    
    Args:
        path (str): 조회할 파라미터 경로 (예: /prod/app/config)
        with_decryption (bool): 암호화된 파라미터 복호화 여부 (기본값: True)
    
    Returns:
        dict: 파라미터 이름을 키로, 파라미터 값을 값으로 하는 딕셔너리
    
    Raises:
        ClientError: 파라미터 조회 실패 시
    
    Example:
        >>> configs = get_parameters_by_path('/prod/app/config')
        >>> print(configs)
        {'/prod/app/config/region': 'ap-northeast-2', '/prod/app/config/timeout': '30'}
    """
    try:
        # 경로 아래의 모든 파라미터 조회
        response = ssm_client.get_parameters_by_path(
            Path=path,
            Recursive=True,  # 하위 경로 포함
            WithDecryption=with_decryption  # SecureString 복호화 여부
        )
        # 파라미터 이름과 값을 딕셔너리로 변환하여 반환
        return {p['Name']: p['Value'] for p in response['Parameters']}
    except ClientError as e:
        # 오류 발생 시 로그 출력 및 예외 재발생
        print(f"Error retrieving parameters: {e}")
        raise e

def lambda_handler(event, context):
    """
    Secrets Manager와 Parameter Store 통합 데모 Lambda 핸들러
    
    이 함수는 AWS Secrets Manager와 Systems Manager Parameter Store에서
    다양한 유형의 시크릿과 파라미터를 조회하는 방법을 보여줍니다.
    
    실행 흐름:
        1. Secrets Manager에서 데이터베이스 자격증명 조회
        2. Secrets Manager에서 API 키 조회
        3. Parameter Store에서 일반 파라미터 조회 (암호화 없음)
        4. Parameter Store에서 암호화된 파라미터 조회 (SecureString)
        5. 경로 기반으로 모든 설정 파라미터 일괄 조회
    
    Args:
        event (dict): Lambda 이벤트 객체 (사용하지 않음)
        context (LambdaContext): Lambda 실행 컨텍스트
    
    Returns:
        dict: API Gateway 응답 형식
            - statusCode (int): HTTP 상태 코드 (200: 성공, 500: 오류)
            - body (str): JSON 형식의 응답 본문
                - message: 처리 결과 메시지
                - region: 조회된 리전 정보
                - config_count: 조회된 설정 파라미터 개수
    
    Example:
        >>> result = lambda_handler({}, None)
        >>> print(result['statusCode'])
        200
        >>> body = json.loads(result['body'])
        >>> print(body['message'])
        Successfully retrieved all secrets and parameters
    """
    try:
        # 1. 데이터베이스 자격증명 조회
        db_credentials = get_secret('prod/db/mysql/credentials')
        print(f"DB Username: {db_credentials.get('username')}")
        
        # 2. API 키 조회
        api_credentials = get_secret('prod/api/external-service')
        print(f"API Key retrieved: {api_credentials.get('api_key')[:10]}...")
        
        # 3. 개별 파라미터 조회
        region = get_parameter('/prod/app/config/region', with_decryption=False)
        print(f"Region: {region}")
        
        # 4. 암호화된 파라미터 조회
        db_connection = get_parameter('/prod/app/config/db-connection-string')
        print(f"DB Connection: {db_connection[:20]}...")
        
        # 5. 경로로 모든 설정 조회
        all_configs = get_parameters_by_path('/prod/app/config')
        print(f"All configs: {list(all_configs.keys())}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully retrieved all secrets and parameters',
                'region': region,
                'config_count': len(all_configs)
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
