# Week 5-3: DynamoDB 테이블 설계 및 GSI 활용

## 실습 개요
DynamoDB 테이블을 생성하고 GSI(Global Secondary Index)를 활용하여 다양한 쿼리 패턴을 구현합니다.

## 파일 설명
- `sample_orders.json`: 샘플 주문 데이터 (batch-write용)

## 테이블 설계
- Partition Key: customerId
- Sort Key: orderId
- GSI: Status-OrderDate-index
