# RDS Multi-AZ 실습 파일

이 패키지는 Amazon RDS Multi-AZ 배포 실습을 위한 SQL 스크립트입니다.

## 📦 포함된 파일

- `init_database.sql` - 데이터베이스 초기화 및 샘플 데이터
- `README.md` - 이 파일

## 🚀 사용 방법

### 1. RDS 인스턴스 연결

EC2 인스턴스에서 MySQL 클라이언트로 RDS에 연결합니다:

```bash
mysql -h mysql-lab-instance.abc123.ap-northeast-2.rds.amazonaws.com -u admin -p
```

비밀번호 입력: `MyPassword123!`

### 2. SQL 스크립트 실행

```bash
mysql -h mysql-lab-instance.abc123.ap-northeast-2.rds.amazonaws.com -u admin -p < init_database.sql
```

또는 MySQL 클라이언트 내에서:

```sql
source init_database.sql;
```

### 3. 데이터 확인

```sql
USE labdb;
SHOW TABLES;
SELECT * FROM customers;
SELECT * FROM orders;
```

## 📋 생성되는 테이블

### customers (고객)
- `customer_id` - 고객 ID (Primary Key)
- `name` - 고객 이름
- `email` - 이메일 (Unique)
- `phone` - 전화번호
- `created_at` - 생성 시간

### products (상품)
- `product_id` - 상품 ID (Primary Key)
- `name` - 상품명
- `price` - 가격
- `stock` - 재고
- `category` - 카테고리
- `created_at` - 생성 시간

### orders (주문)
- `order_id` - 주문 ID (Primary Key)
- `customer_id` - 고객 ID (Foreign Key)
- `order_date` - 주문 날짜
- `total_amount` - 총 금액
- `status` - 주문 상태

## 🔍 샘플 쿼리

### 고객별 주문 조회
```sql
SELECT 
    c.name,
    o.order_id,
    o.order_date,
    o.total_amount,
    o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY c.customer_id, o.order_date DESC;
```

### 주문 상태별 집계
```sql
SELECT 
    status,
    COUNT(*) as order_count,
    SUM(total_amount) as total_revenue
FROM orders
GROUP BY status;
```

### 고객별 총 주문 금액
```sql
SELECT 
    c.name,
    COUNT(o.order_id) as order_count,
    SUM(o.total_amount) as total_spent
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC;
```

## 💡 페일오버 테스트

### 1. 현재 연결 확인
```sql
SELECT @@hostname;
SHOW VARIABLES LIKE 'server_id';
```

### 2. 페일오버 실행 (RDS 콘솔)
1. RDS 콘솔에서 인스턴스 선택
2. Actions > Reboot
3. "Reboot with failover" 체크
4. Confirm

### 3. 페일오버 시간 측정
- **예상 시간**: 60-120초
- **DNS 전환**: 자동
- **애플리케이션**: 재연결 필요

### 4. 페일오버 후 확인
```sql
SELECT @@hostname;
SHOW VARIABLES LIKE 'server_id';
```

서버 ID가 변경되었다면 페일오버 성공!

## 🔧 트러블슈팅

### 연결 실패
**오류**: `ERROR 2003 (HY000): Can't connect to MySQL server`
- **확인 1**: 보안 그룹에서 3306 포트 허용 확인
- **확인 2**: EC2가 RDS와 같은 VPC에 있는지 확인
- **확인 3**: RDS 엔드포인트 주소 확인

### 권한 오류
**오류**: `ERROR 1044 (42000): Access denied`
- **확인**: 마스터 사용자 이름/비밀번호 확인
- **확인**: 데이터베이스 이름 확인 (`labdb`)

## 📚 학습 포인트

1. **Multi-AZ**: Primary와 Standby가 서로 다른 AZ에 배포
2. **동기식 복제**: 데이터 일관성 보장
3. **자동 페일오버**: 60-120초 내 자동 전환
4. **DNS 엔드포인트**: 애플리케이션 코드 변경 불필요
5. **고가용성**: 99.95% SLA 제공

## 🔗 추가 리소스

- [RDS Multi-AZ 공식 문서](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.MultiAZ.html)
- [RDS 페일오버 프로세스](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Concepts.MultiAZ.Failover.html)
- [RDS 모범 사례](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_BestPractices.html)
