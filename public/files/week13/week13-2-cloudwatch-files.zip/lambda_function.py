"""
AWS Lambda 함수: CloudWatch 커스텀 메트릭 전송

이 Lambda 함수는 Amazon CloudWatch에 커스텀 메트릭을 전송하는 방법을 보여줍니다.
애플리케이션의 비즈니스 메트릭을 CloudWatch로 전송하여 모니터링 및 알람을 설정할 수 있습니다.

주요 기능:
    1. 주문 처리 건수 메트릭 전송 (OrdersProcessed)
    2. 응답 시간 메트릭 전송 (ResponseTime)
    3. 랜덤 값을 사용한 시뮬레이션

환경 변수:
    없음

트리거:
    EventBridge 스케줄 (1분마다 실행)

작성자: AWS 실습 가이드
버전: 1.0.0
"""

import boto3
import random
from datetime import datetime

# CloudWatch 클라이언트 초기화
cloudwatch = boto3.client('cloudwatch')

def lambda_handler(event, context):
    """
    CloudWatch에 커스텀 메트릭을 전송하는 Lambda 핸들러
    
    이 함수는 애플리케이션의 비즈니스 메트릭을 CloudWatch로 전송합니다.
    실제 환경에서는 랜덤 값 대신 실제 애플리케이션 데이터를 사용합니다.
    
    전송하는 메트릭:
        - OrdersProcessed: 처리된 주문 건수 (10-100 사이 랜덤)
        - ResponseTime: 응답 시간 (0.1-2.0초 사이 랜덤)
    
    Args:
        event (dict): Lambda 이벤트 객체 (EventBridge 스케줄)
        context (LambdaContext): Lambda 실행 컨텍스트
    
    Returns:
        dict: API Gateway 응답 형식
            - statusCode (int): HTTP 상태 코드 (200: 성공)
            - body (str): 응답 메시지
    
    Example:
        >>> result = lambda_handler({}, None)
        >>> print(result['statusCode'])
        200
        >>> print(result['body'])
        Custom metrics sent successfully
    """
    # 커스텀 메트릭 전송
    # put_metric_data()를 사용하여 여러 메트릭을 한 번에 전송
    cloudwatch.put_metric_data(
        Namespace='CustomApplication',  # 커스텀 네임스페이스 (메트릭 그룹)
        MetricData=[
            {
                'MetricName': 'OrdersProcessed',  # 메트릭 이름
                'Value': random.randint(10, 100),  # 메트릭 값 (실제 환경에서는 실제 데이터 사용)
                'Unit': 'Count',  # 단위 (Count, Seconds, Bytes 등)
                'Timestamp': datetime.utcnow()  # 타임스탬프 (UTC)
            },
            {
                'MetricName': 'ResponseTime',  # 응답 시간 메트릭
                'Value': random.uniform(0.1, 2.0),  # 0.1-2.0초 사이 랜덤 값
                'Unit': 'Seconds',  # 단위: 초
                'Timestamp': datetime.utcnow()  # 타임스탬프 (UTC)
            }
        ]
    )
    
    # 성공 응답 반환
    return {
        'statusCode': 200,
        'body': 'Custom metrics sent successfully'
    }
